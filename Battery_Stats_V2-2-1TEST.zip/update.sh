#!/system/bin/sh
MODDIR="/data/adb/modules/battery_stats"
BAT_PATH="/sys/class/power_supply/battery"

FULL=$(cat $BAT_PATH/charge_full)
DESIGN=$(cat $BAT_PATH/charge_full_design)
CYCLES=$(cat $BAT_PATH/cycle_count)
TEMP=$(cat $BAT_PATH/temp)
VOLT=$(cat $BAT_PATH/voltage_now)

HEALTH=$((FULL * 100 / DESIGN))

TEMP_WHOLE=$((TEMP / 10))
TEMP_DECIMAL=$((TEMP % 10))
[ $TEMP_DECIMAL -lt 0 ] && TEMP_DECIMAL=$((TEMP_DECIMAL * -1))

V_WHOLE=$((VOLT / 1000000))
V_DECIMAL=$(( (VOLT % 1000000) / 10000 ))

INFO="Здоровье: $HEALTH% | $V_WHOLE.$V_DECIMAL V | Циклов: $CYCLES | T: $TEMP_WHOLE.$TEMP_DECIMAL°C | @ausyabatt"

sed -i "s/^description=.*/description=$INFO/" "$MODDIR/module.prop"
touch "$MODDIR/module.prop"
chmod 644 "$MODDIR/module.prop"

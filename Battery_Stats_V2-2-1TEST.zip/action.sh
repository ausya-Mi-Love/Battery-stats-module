#!/system/bin/sh
MODDIR=${0%/*}

sh "$MODDIR/update.sh"
echo "Updated | Обновлено"
